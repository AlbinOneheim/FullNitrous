#include <Wire.h>

void read_int16(char flag)
{
  int num;
  num = Wire.read(); 
  num = (num << 8) | Wire.read();
  while (Wire.available())
  {
    Wire.read();
  }
  switch (flag)
  {
    case 'A':
      m[0].step_ = num;
      break;
    case 'B':
      m[1].step_ = num;
      break;
    case 'C':
      m[2].step_ = num;
      break;
    case 'D':
      m[3].step_ = num;
      break;
    case 'E':
      m[4].step_ = num;
      break;
    case 'F':
      pbi.break_point = num;
      break;
    case 'G':
      pbi.times = num;
      break;
    case 'J':
      if(num == 1)
      {
        pbi.type = 'a';
      }
      else if (num == 2)
      {
        pbi.type = 'r';
      }
      else if (num == 3)
      {
        pbi.type = 'b';
      }
      Serial.println(pbi.type);
      break;
    case 'f':
      s[0].angle = num;
      break;
    case 'g':
      s[1].angle = num;
      break;
    default:
      return;
  }
  return;
}

void read_compound()
{
  byte n = Wire.read();
  int i; int i2;
  for(i = 0; i < 7; i++)
  {
    for(i2 = 0; i2 < 2; i2++)
    {
      pbi.file[n][i][i2] = Wire.read();
    }
  }
  Serial.println(n);
}

// Handles a I2C message.
void i2c_receive_event(int a)
{
  char flag = Wire.read();
  //character means step amount for motor 1
  if (flag == 'H')
  {
    read_compound();
  }
  else if (flag == 'A' || flag == 'B' || flag == 'C' || flag == 'D' || flag == 'E' || 
           flag == 'F' || flag == 'G' || flag == 'J' || flag == 'f' || flag == 'g')
  {
    read_int16(flag);
  }
  else if (flag == 'I')
  {
    start_playback();
    Serial.println("tits");
    return;
  }
  else if (flag == 'T')
  {
    while (Wire.available())
    {
      Wire.read();
    }
    TRANSFORM();
    return;
  }
}

