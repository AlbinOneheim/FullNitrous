void TRANSFORM()
{
  int i[5];
  int step_[5];
  for(i[0] = 0; i[0] < 5; i[0]++)
  {
    if (m[i[0]].step_ < 0)
    {
      m[i[0]].step_ = -m[i[0]].step_;
      m[i[0]].dir = true;
    }
    else
    {
      m[i[0]].dir = false;
    }
    step_[i[0]] = m[i[0]].step_;
  }
  // Local variables.
  int largest = gl(step_, sizeof(step_)/sizeof(step_[0]));
  int J[5];
  float r[5];
  int phase[4];
  signed char md[3];
  for (i[0] = 0; i[0] < 5; i[0]++)
  {
    J[i[0]] = 1;
    r[i[0]] = (float)largest / m[i[0]].step_;
    if (m[i[0]].step_ == 0)
    {
      r[i[0]] = largest + 1;
    }
  }
  if (largest < 2400)
  {
    for(i[0] = 0; i[0] < 3; i[0]++)
    {
      phase[i[0]] = round(((1.0/3) * largest));
    }
    if ((phase[0] + phase[1] + phase[2]) != largest)
    {
      int diff = largest - (phase[0] + phase[1] + phase[2]);
      if (diff % 3 == 0)
      {
        for(i[0] = 0; i[0] < 3; i[0]++)
        {
          phase[i[0]] += diff / 3;
        }
      }
      else if (diff % 2 == 0)
      {
        for(i[0] = 0; i[0] < 2; i[0]++)
        {
          phase[i[0]] += diff / 2;
        }
      }
      else
      {
        phase[1] += diff;
      }
    }
  }
  else if (largest >= 2400)
  {
    phase[0] = 800; 
    phase[1] = largest - 1600;
    phase[2] = 800;
  }
  i[4] = 0;
  for (i[2] = 0; i[2] < 3; i[2]++)
  {
    if (i[2] == 0)
    {
      phase[3] = phase[0]; md[0] = 1; md[1] = -1; md[2] = 1;
    }
    else if (i[2] == 1)
    {
      phase[3] = phase[1]; md[0] = 0; md[1] = 0; md[2] = 0;
    }
    else
    {
      phase[3] = phase[2]; md[0] = 1; md[1] = 1; md[2] = -1;
    }
    for (i[0] = 0; i[0] < phase[3]; i[0]++)
    { 
      for (i[1] = 0; i[1] < 2; i[1]++)
      {   
        for (i[3] = 0; i[3] < 5; i[3]++)
        {
          PORTD = m[i[3]].dir ? PORTD | _BV(DIRECTIONPIN) : PORTD & ~_BV(DIRECTIONPIN);
          if (i[4]+1 >= round(J[i[3]] * r[i[3]]))
          {
            PORTD |= _BV(m[i[3]].output_pin);
            //Serial.println("m[1] 1 ");
            J[i[3]]++;
          }
          else
          {
            PORTD &= ~_BV(m[i[3]].output_pin);
            //Serial.println("m[1] 0 ");
          }
        }
        delayMicroseconds(MAXDELAY - SUBDELAY / (md[0] + pow(2.71, (i[0]/(phase[3]/10.0)) * md[1] + 5 * md[2])));
      }
      i[4]++;
    }
  }
  Serial.println("done");
  
}

void write_val_to_all(int n, char negate)
{
  int i; int a;
  for(i = 0; i < 5; i++)
  {
      a = pbi.file[n][i][0]; 
      a = (a << 8) | pbi.file[n][i][1];
      m[i].step_ = round(a * (stepper360 / 360)) * negate;
  }
  for(i = 0; i < 2; i++)
  {
      a = pbi.file[n][i][0]; 
      a = (a << 8) | pbi.file[n][i][1];
      s[i].angle = a;
  }  
}

void additive()
{
  int i;
  int i2;
  for(i2 = 0; i2 < pbi.times; i2++)
  {
    for(i = 0; i < pbi.break_point; i++)
    {
      write_val_to_all(i, 1);
      TRANSFORM();
    }
    if(pbi.times <= 0)
    {
      pbi.times--;
    }
  }
  cleanup_pbi();
}
void recursive()
{
  int i;
  int i2;
  int i3;
  int origin[5]; origin[0] = 0; origin[1] = 0; origin[2] = 0; origin[3] = 0; origin[4] = 0;

  for(i = 0; i < pbi.break_point; i++)
  {
    write_val_to_all(i, -1);
    for(i2 = 0; i2 < 5; i2++)
    {
      origin[i2] += m[i2].step_;
    }
  }
  for(i2 = 0; i2 < pbi.times; i2++)
  {
    for(i = 0; i < pbi.break_point; i++)
    {
      write_val_to_all(i, 1);
      TRANSFORM();
    }
    for(i3 = 0; i3 < 5; i3++)
    {
      m[i3].step_ = origin[i3];
    }
    TRANSFORM();
    if(pbi.times <= 0)
    {
      pbi.times--;
    }
  }
}
void bidirectional()
{
  int i;
  int i2;
  for(i2 = 0; i2 < pbi.times; i2++)
  {
    for(i = 0; i < pbi.break_point; i++)
    {
      write_val_to_all(i, 1);
      TRANSFORM();
    }
    for(i = 0; i < pbi.break_point; i++)
    {
      write_val_to_all(i, -1);
      TRANSFORM();
    }
    if(pbi.times <= 0)
    {
      pbi.times--;
    }
  }
  cleanup_pbi();
}
void start_playback()
{
  //TELEMETRY
  int i;
  int i2;
  Serial.print("Breakpoint: ");
  Serial.println(pbi.break_point);
  
  Serial.print("Times: ");
  Serial.println(pbi.times);

  Serial.print("Type: ");
  Serial.println(pbi.type); 

  Serial.println("Coordinates: ");
  for(i = 0; i < pbi.break_point; i++)
  {
    write_val_to_all(i, 1);
    for(i2 = 0; i2 < 5; i2++)
    {
      Serial.print("m");
      Serial.print(i2);
      Serial.print(": ");
      Serial.println(m[0].step_); 
    }
  }
  //TELEMETRY
  if(pbi.times == 0)
  {
    pbi.times = -1;
  }
  switch(pbi.type)
  {
    case 'a':
      additive();
      break;
    case 'r':
      recursive();
      break;
    case 'b':
      bidirectional();
      break;
    default:
      Serial.println("Type was not indentifialbe");
      break;
  }
}
