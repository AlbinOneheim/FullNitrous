void cleanup_pbi()
{
  pbi.times = 0;
  pbi.break_point = 0;
  pbi.type = '\0';
  int i; int i2; int i3;
  for(i = 0; i < 50; i++)
  {
    for(i2 = 0; i2 < 5; i2++)
    {
      for(i3 = 0; i3 < 2; i3++)
      {
        pbi.file[i][i2][i3] = 0;
      }
    }
  }
}

// Returns the largest integer between three.
int gl(int a[], int len)
{
    int i;
    int last = 0;
    for(i = 0; i < len; i++)
    {
        if (a[i] > last)
        {
            last = a[i];
        }
    }
    return last;
}

setsteppins()
{ 
  int i;
  for(i = 0; i < 5; i++)
  {
    m[i].output_pin = 3+i;
    pinMode(m[i].output_pin, OUTPUT);
    digitalWrite(m[i].output_pin, 0);
  }
}

