/*following functions are for the basic IO between the arm and website*/

var current = "";
var currenttheme = "light";
var ip = window.location.hostname;
var port = window.location.port;
var socket = new WebSocket("ws://"+ip+":"+port+"/ws", "TCP");

socket.addEventListener("open", function (event)
{
    refresh();
    document.getElementById("state").style.color = "green";
    document.getElementById("state").innerHTML = "Connected &ofcir;";
});

socket.addEventListener("close", function (event)
{
    document.getElementById("state").style.color = "red";
    document.getElementById("state").innerHTML = "Disconnected &otimes;";
});

socket.addEventListener('message', function (event) 
{
    if(event.data.startsWith("/COORDINATEDATA/"))
    {
        alert(event.data.replace("/COORDINATEDATA/", ""));
    }
    else if(event.data.startsWith("/NAME/"))
    {
        var msg = event.data;
        msg = msg.replace("/NAME/","");
        msg = msg.substring(0, msg.length-1);
        make_recordingbox(msg);
        make_keyframebox(msg);
    }
    else if(event.data.startsWith("/FRAMENR/"))
    {
        make_keyframebox();
    }
    else if(even.data.startsWith("/MSG/"))
    {
        alert(event.data.replace("/MSG/",""));
    }
    return;
});

/*following functions are for interacting with the html and styles*/

function make_recordingbox(name)
{
    var s = 
    `<div class = "frame">
        <span>Rec: `+name+`</span>
        <button class="btn btnsmall" onclick="select(&quot;`+name+`&quot;)">Select</button>
    </div>`;
    var div = document.createElement('div');
    div.innerHTML = s;
    document.getElementById("BASEDGOD").appendChild(div);
}

function make_keyframebox(name)
{
    var s = 
    `<div class = "frame">
        <span>Name: `+name+`</span>
        <button class="btn btnsmall" onclick="select(&quot;`+name+`&quot;)">Open</button>
    </div>`;
    var div = document.createElement('div');
    div.innerHTML = s;
    document.getElementById("BASEDGOD2").appendChild(div);
}

function make_keyframe(number)
{
    var s = 
    `<div class = "frame">
        <span>`+number+`: </span>
        <button class="btn btnsmall" onclick="select(&quot;`+name+`&quot;)">Edit</button>
    </div>`;
    var div = document.createElement('div');
    div.innerHTML = s;
    document.getElementById("BASEDGOD3").appendChild(div);
}


function openNav() 
{
    document.getElementById("nav2").style.width = "250px";
}

function closeNav() 
{
    document.getElementById("nav2").style.width = "0";
    current = "";
}

function changetheme()
{
    if(currenttheme == "light")
    {
        currenttheme = "dark";
        document.documentElement.style.setProperty("--foreground",      "#23b7e0");
        document.documentElement.style.setProperty("--background",      "#1D1D1D");
        document.documentElement.style.setProperty("--disconnected",    "red");
        document.documentElement.style.setProperty("--pagebackground",  "#121212");
        document.documentElement.style.setProperty("--buttonpressed",   "#0087ad");
        document.documentElement.style.setProperty("--placeholder",     "#7ec3d6");
        document.documentElement.style.setProperty("--type1colorgroup", "rgba(0, 255, 0, 0.150)");
        document.documentElement.style.setProperty("--type2colorgroup", "rgba(183, 0, 255, 0.150)");
    }
    else if (currenttheme == "dark")
    {
        currenttheme = "light";
        document.documentElement.style.setProperty("--foreground",      "#23b7e0");
        document.documentElement.style.setProperty("--background",      "#e2e2e2");
        document.documentElement.style.setProperty("--disconnected",    "red");
        document.documentElement.style.setProperty("--pagebackground",  "#ededed");
        document.documentElement.style.setProperty("--buttonpressed",    "#0087ad");
        document.documentElement.style.setProperty("--placeholder",     "#7ec3d6");
        document.documentElement.style.setProperty("--type1colorgroup", "rgba(0, 255, 0, 0.150)");
        document.documentElement.style.setProperty("--type2colorgroup", "rgba(183, 0, 255, 0.150)");
    }
    closeNav();
}

/*following functions are for spesific operations and calls for spesific pages*/

function select(name)
{
    current = name;
    alert("Selection: "+current);
}

function checkvar(name)
{
    if(name == "")
    {
        alert("ERROR: You did not select any recording to perform action on");
        return 0;
    }
    else if(name != "")
    {
        return 1;
    }
}

function refresh()
{
    var myNode = document.getElementById("BASEDGOD");
    while (myNode.firstChild) 
    {
        myNode.removeChild(myNode.firstChild);
    }
    myNode = document.getElementById("BASEDGOD2");
    while (myNode.firstChild) 
    {
        myNode.removeChild(myNode.firstChild);
    }
    myNode = document.getElementById("BASEDGOD3");
    while (myNode.firstChild) 
    {
        myNode.removeChild(myNode.firstChild);
    }
    fetchnames();
    fetchframes();
}

/*Following are different request functions*/

function frametransform(element)
{
    if (element == "servo")
    {
        var s1 = document.getElementById("servo1(2)").value;
        var s2 = document.getElementById("servo2(2)").value;
        if (s1 < 0 || s1 > 180 || s2 < 0 || s2 > 180)
        {
            return;
        }
        s1 = "0".repeat(3 - s1.length) + s1;
        s2 = "0".repeat(3 - s2.length) + s2;

        alert("/frametransform/servo/"+s1+s2+"/");
        socket.send("/frametransform/servo/"+s1+s2+"/");
    }
    else
    {
        var val = document.getElementById("amount").value;
        alert("/frametransform/"+element+"/"+val+"/");
        socket.send("/frametransform/"+element+"/"+val+"/");
    }
}

function transform()
{
    var j1 = document.getElementById("joint1").value;
    var j2 = document.getElementById("joint2").value;
    var j3 = document.getElementById("joint3").value;
    var j4 = document.getElementById("joint4").value;
    var j5 = document.getElementById("joint5").value;
    var s1 = document.getElementById("servo1").value;
    var s2 = document.getElementById("servo2").value;

    socket.send("/transform/"+j1+"/"+j2+"/"+j3+"/"+j4+"/"+j5+"/"+s1+"/"+s2+"/");
    alert("/transform/"+j1+"/"+j2+"/"+j3+"/"+j4+"/"+j5+"/"+s1+"/"+s2+"/");
}

function save()
{
    var name = document.getElementById("ti1").value;
    socket.send("/save/"+name+"/");
    alert("/save/"+name+"/");
    return;
}

function fetchnames()
{
    socket.send("/fetchnames/");
    alert("/fetchnames/");
}

function rename()
{   
    if(checkvar(current))
    {
        var newname = prompt("Enter new name:", "");
        if (newname == null || newname == "")
        {
            alert("ERROR: Invalid input");
            return; 
        }
        else if (newname.length > 8)
        {
            alert("ERROR: Name length cannot exceed 8 characters or have slashes (/) in them");
            return;
        }
        socket.send("/rename/"+current+"/"+newname+"/");
        alert("/rename/"+current+"/"+newname+"/");
    }
    refresh();
    return;
}

function del()
{
    if(checkvar(current))
    {
        socket.send("/delete/"+current+"/");
        alert("/delete/"+current+"/");
    }
    refresh();
    return;
}

function playback()
{
    if(checkvar(current))
    {
        var type = document.getElementById("sl").value;
        var times = document.getElementById("ti1").value;

        if (type == "" || times == "")
        {
            return;
        }
        else
        {
            socket.send("/playback/"+current+"/"+type+"/"+times+"/");
            alert("/playback/"+current+"/"+type+"/"+times+"/");
        }
    }
    return;
}

function fetchframes()
{
    socket.send("/fetchframes/");
    alert("/fetchframes/");
}