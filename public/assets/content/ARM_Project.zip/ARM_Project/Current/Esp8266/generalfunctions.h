void transform(int values[7])
{
  int i;
  char flaglist[] = {'A', 'B', 'C', 'D', 'E', 'f', 'g'};
  
  for(i = 0; i < 7; i++)
  {
    Serial.println(values[i]);
    i2c_send_int16(values[i], flaglist[i], I2C_MOTOR_O);
  }
  
  i2c_send_begin_transform(I2C_MOTOR_O);
  return;
}

String get_(char seperator, String data, int index)
{
    int i, seperatorcount;
    String container;

    i = 0;
    seperatorcount = 0;
    container = "";

    for (i = 0; i < data.length(); i++)
    {
        if (data[i] == seperator)
        {
            seperatorcount++;
            continue;
        }
        if (seperatorcount == index)
        {
            container += data[i];
        }
    }
    return container;
}
