#include "FS.h"

void init_fs()
{
  if(SPIFFS.begin())
  {
    Serial.println();
    Serial.println("SPIFFS mounted");  
  }
  else
  {
    Serial.println("SPIFFS could not be mounted"); 
  }
}

void rename_file(String name_, String directory, String newname )
{
  if(SPIFFS.rename("/"+directory+"/"+name_+"/", "/"+directory+"/"+newname+"/"))
  {
    Serial.println("file was renamed");
  }
  else
  {
    Serial.println("file was not renamed");
  }
}
int count_files(String directory)
{
  Dir dir = SPIFFS.openDir("/"+directory);
  int i = 0;
  while(dir.next())
  {
    i++;
  }
  return i;
}

String getname_file(String directory, int index)
{
  Dir dir = SPIFFS.openDir("/"+directory);
  int i = 0;
  for(i = 0; i < index; i++)
  {
    dir.next();
  }
  return dir.fileName();
}

void del_file(String name_, String directory, bool all)
{
  if(all)
  {
    Dir dir = SPIFFS.openDir("/"+directory);
    while(dir.next())
    {
      del_file(dir.fileName(), "--", 0);
    }
    return;
  }
  String dir = "/"+directory+"/"+name_+"/";
  if (directory == "--")
  {
    dir = name_;
  }
  
  if(SPIFFS.remove(dir))
  {
    Serial.println("removed file with success");
  }
  else
  {
    Serial.println("failed to remove file");
  }
}

int size_file(String name_, String directory)
{
  File f = SPIFFS.open("/"+directory+"/"+name_+"/", "a+");
  if (!f) 
  {
      Serial.println("file open failed");
  }
  else
  {
      Serial.println("file open success");
  }
  int s = f.size();
  f.close();
  return s;
}



void write_frame(String name_, int index, int j[], int s[])
{
  //check if file exists
  String directory = "COORDINATES";
  if (!SPIFFS.exists("/"+directory+"/"+name_+"/"))
  {
    Serial.println("file error");
    return;
  }
  //check index range
  if(index > 60 || index < 0)
  {
    Serial.println("index error");
    return;
  }
  //open file
  File f = SPIFFS.open("/"+directory+"/"+name_+"/", "a+");
  //move to index
  f.seek(index*14, SeekSet);
  //write values
  int i;
  for(i = 0; i < 5; i++)
  {
    f.write((j[i] >> 8) & 0xFF);
    f.write(j[i] & 0xFF);
    
    Serial.println((j[i] >> 8) & 0xFF);
    Serial.println(j[i] & 0xFF);
  }
  for(i = 0; i < 2; i++)
  {
    f.write((s[i] >> 8) & 0xFF);
    f.write(s[i] & 0xFF);
    
    Serial.println((s[i] >> 8) & 0xFF);
    Serial.println(s[i] & 0xFF);
  }
  //close file
  f.close();
}

void readframe(String name_, int index, byte container[])
{
  //check if file exists
  String directory = "COORDINATES";
  if (!SPIFFS.exists("/"+directory+"/"+name_+"/"))
  {
    Serial.println("file error");
    return;
  }
  //check index range
  if(index > 60 || index < 0)
  {
    Serial.println("index error");
    return;
  }
  //openfile
  File f = SPIFFS.open("/"+directory+"/"+name_+"/", "a+");
  //go to index
  f.seek(index*14, SeekSet);
  //read index
  int i;
  for(i = 0; i < 14; i++)
  {
    container[i] = f.read();
  }
  //close file
  f.close();
}

void make_framefile(String name_)
{
  //check if file does not exist
  String directory = "COORDINATES";
  if (SPIFFS.exists("/"+directory+"/"+name_+"/"))
  {
    Serial.println("file error");
    return;
  }
  //create file
  File f = SPIFFS.open("/"+directory+"/"+name_+"/", "a+");
  //close file
  f.close();
  //write 0 to all
  int i;
  int a[7] = {0,0,0,0,0};
  int b[2] = {0,0};
  for(i = 0; i < 60; i++)
  {
    write_frame(name_, i, a, b);
  }
}















