void playback_req(String data)
{

  String name_ = get_(MSGSEP, data, 2);
  String type = get_(MSGSEP, data, 3);
  int times = get_(MSGSEP, data, 4).toInt();

  
  int size_ = size_file(name_, "COORDINATES") / 14;

  int i;
  byte contain[14];
  for(i = 0; i < size_; i++)
  {
    readframe(name_, i, contain);
    i2c_send_compound(contain, i, I2C_MOTOR_O);
  }
  if(type == "ad")
  {
    i2c_send_int16(1, 'J', I2C_MOTOR_O);
  }
  else if(type == "re")
  {
    i2c_send_int16(2, 'J', I2C_MOTOR_O);
  }
  else if(type == "bi")
  {
    i2c_send_int16(3, 'J', I2C_MOTOR_O);
  }
  i2c_send_int16(times, 'G', I2C_MOTOR_O);
  i2c_send_int16(size_, 'F', I2C_MOTOR_O);
  i2c_send_char('I', I2C_MOTOR_O);
}

void delete_req(String data)
{
  String name_ = get_(MSGSEP, data, 2);
  
  del_file(name_, "COORDINATES", 0);
}

void rename_req(String data)
{
  String name_ = get_(MSGSEP, data, 2);
  String newname_ = get_(MSGSEP, data, 3);
  
  rename_file(name_, "COORDINATES", newname_);
}

void fetchnames_req(uint32_t client_)
{
  int files = count_files("COORDINATES");
  int i;
  for(i = 1; i < files+1; i++)
  {
    String name_ = getname_file("COORDINATES", i);
    name_.replace("/COORDINATES/", "");
    name_ = "/NAME/"+name_;
    ws.text(client_, name_);
    Serial.print("FETCHNAMES: ");
    Serial.println(name_);
  }
}

void fetchframes_req(String data, uint32_t client_)
{
  String name_ = get_(MSGSEP, data, 2);
  
  int size_ = size_file(name_, "COORDINATES") / 14;
  String msg = "/FRAMENR/" + String(size_);
  ws.text(client_, msg);
}

void save_req(String data)
{
  
  String name_ = get_(MSGSEP, data, 2);
  
  int frame = get_(MSGSEP, data, 3).toInt();
  
  write_frame(name_, frame, cy.joint, cy.angle);
  return;
}

void frametransform_req(String data)
{
  char type = get_(MSGSEP, data, 2)[0];
  int value = get_(MSGSEP, data, 3).toInt();
  
  switch (type)
  {
    case 'a':
      cy.joint[0] = value;
      break;
    case 'b':
      cy.joint[1] = value;
      break;
    case 'c':
      cy.joint[2] = value;
      break;
    case 'd':
      cy.joint[3] = value;
      break;
    case 'e':
      cy.joint[4] = value;
      break;
    case 'f':
      cy.angle[0] = value;
      break;
    case 'g':
      cy.angle[2] = value;
      break;
  }
  return;
}

void transform_req(String data)
{
  int joint1 = get_(MSGSEP, data, 2).toInt();
  int joint2 = get_(MSGSEP, data, 3).toInt();
  int joint3 = get_(MSGSEP, data, 4).toInt();
  int joint4 = get_(MSGSEP, data, 5).toInt();
  int joint5 = get_(MSGSEP, data, 6).toInt();
  int servo1 = get_(MSGSEP, data, 7).toInt();
  int servo2 = get_(MSGSEP, data, 8).toInt();

  int a[5];
  int b[2];
  a[0] = round(joint1 * (stepper360 / 360));
  a[1] = round(joint2 * (stepper360 / 360));
  a[2] = round(joint3 * (stepper360 / 360));
  a[3] = round(joint4 * (stepper360 / 360));
  a[4] = round(joint5 * (stepper360 / 360));
  b[0] = servo1;
  b[1] = servo2;
  
  transform(a);
}
