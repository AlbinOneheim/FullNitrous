#include <Wire.h>

void i2c_send_char(char ch, char address)
{
  Wire.beginTransmission(address);
  Wire.write(ch);
  Wire.endTransmission();
  return;
}

void i2c_send_compound(byte vals[], byte n, char address)
{
  Wire.beginTransmission(address);
  Wire.write('H');
  Wire.write(n);
  Wire.write(vals, 10);
  Wire.endTransmission();
  Serial.println(n);
  return;
}

void i2c_send_int16(int integer, char flag, char address)
{
  //overflow checking
  if (integer > 32768 || integer < -32768)
  {
    return;
  }
  unsigned char intarray[2];
  intarray[0] = (integer >> 8) & 0xFF;
  intarray[1] = integer & 0xFF;
  Wire.beginTransmission(address);
  Wire.write(flag);
  Wire.write(intarray, 2);
  Wire.endTransmission();
  return;
}

void i2c_send_begin_transform(char address)
{
  Wire.beginTransmission(address);
  Wire.write('T');
  Wire.endTransmission();
  return;
}
