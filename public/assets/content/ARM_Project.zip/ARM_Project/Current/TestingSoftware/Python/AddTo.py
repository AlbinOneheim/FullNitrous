import matplotlib.pyplot as plt
import matplotlib
from math import *

def goto()
    theta2 = atan2(sin(theta2),cos(theta2)

    theta1 = atan2((k1*yn - k2*xn),(k1*xn-k2*yn))

    theta3 = phi - (theta1 + theta2)



    k1 = l1 + l2*cos(theta2)
    k2 = l2 * sin(theta2)
    cos(theta2) = (x**2 + y**2 - l1**2 - l2**2) / 2 * l1 * l2
    sin(theta2) = sqrt((1 - cos**2(theta2)))
    xn = x - l3*cos(phi)
    yn = y - l3*sin(phi)
    phi = theta1 + theta2 + theta3















