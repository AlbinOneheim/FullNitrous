import matplotlib.pyplot as plt
import matplotlib
from matplotlib.collections import PatchCollection
from matplotlib.patches import Polygon
import numpy as np

fig,ax = plt.subplots(1)


patches = []
patches2 = []
patches3 = []

res = 20
rres = int(360/res)
op = 0.1

from math import *

r1 = 15
r2 = 10
r3 = 5

x1 = r1
y1 = 0

def rotate(x1,y1,x2,y2):
    
    x = ((x2 - x1) * cos(radians(theta)) - (y2 - y1) * sin(radians(theta))) + x1
    y = ((x2 - x1) * sin(radians(theta)) + (y2 - y1) * cos(radians(theta))) + y1

    return (x,y)



l1 = []
l2 = []
l3 = []

for theta in range(0,360,res):
    
    o1, o2 = rotate(0,0,x1,y1)

    l1.append(o1)
    l1.append(o2)

    for theta in range(0,360,res):
        
        x2 = o1 + r2
        y2 = o2
        
        o3, o4 = rotate(o1,o2,x2,y2)
        l2.append(o3)
        l2.append(o4)

        for theta in range(0,360,res):
        
            x3 = o3 + r3
            y3 = o4
            
            o5, o6 = rotate(o3,o4,x3,y3)
            
            l3.append(o5)
            l3.append(o6)

verts1 = np.array(l1)
verts2 = np.array(l2)
verts3 = np.array(l3)

verts1.shape = (rres,2)
verts2.shape = (rres,rres,2)
verts3.shape = (rres,rres,rres,2)

for i in range(rres):
    for i2 in range(rres):
        polygon = Polygon(verts3[i,i2],closed=True)
        patches3.append(polygon)

for i in range(rres):
    polygon = Polygon(verts2[i],closed=True)
    patches2.append(polygon)

polygon = Polygon(verts1,closed=True)
patches.append(polygon)


collection = PatchCollection(patches,alpha=op)
collection2 = PatchCollection(patches2,alpha=op)
collection3 = PatchCollection(patches3,alpha=op)

ax.add_collection(collection3)
ax.add_collection(collection2)
ax.add_collection(collection)

collection.set_color("#ff0000")
collection2.set_color("#00ff00")
collection3.set_color("#0000ff")

ax.autoscale_view()
            
plt.gca().set_aspect("equal", adjustable="box")
plt.show()
