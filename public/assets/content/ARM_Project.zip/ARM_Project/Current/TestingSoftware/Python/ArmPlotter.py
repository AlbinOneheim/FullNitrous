import matplotlib.pyplot as plt
import matplotlib
from math import *

r1 = 15
r2 = 10
r3 = 5

x1 = r1
y1 = 0

def rotate(x1, y1, x2, y2, thetapersonal, parenttheta):

    theta = parenttheta + thetapersonal

    x = ((x2 - x1) * cos(radians(theta)) - (y2 - y1) * sin(radians(theta))) + x1
    y = ((x2 - x1) * sin(radians(theta)) + (y2 - y1) * cos(radians(theta))) + y1

    return (x,y)


angle_a = 20
angle_b = 40
angle_c = 60

o1, o2 = rotate(0,0,x1,y1,angle_a, 0)


        
x2 = o1 + r2
y2 = o2

o3, o4 = rotate(o1,o2,x2,y2, angle_b, angle_a)


        
x3 = o3 + r3
y3 = o4

o5, o6 = rotate(o3,o4,x3,y3, angle_c, angle_a + angle_b)


x = [0,o1,o3,o5]
y = [0,o2,o4,o6]

plt.plot(x,y,color = 'brown', marker = 'o')

plt.show()













