import math
import socket
class Arm():
    def __init__(self, ipv4, port="6969", encoding="UTF-8"):
        try:
            int(port)
        except:
            raise CustomException("PortError, syntax error")
        else:
            port = int(port)
        if port < 1081:
            raise CustomException("PortError, port < 1081")
        elif port > 65535:
            raise CustomException("PortError, port > 65535")
        try:
            socket.inet_aton(ipv4)
        except:
            raise CustomException("IpError, illegal ip adress")
        self.ip = ipv4
        self.port = int(port)
        self.joints = 3
        self.socket = None
        self.addr = None
        self.connected = False
        self.encoding = encoding
        
    def cos(self, x):
        return math.cos(math.radians(x))

    def sin(self, x):
        return math.sin(math.radians(x))

    def tan(self, x):
        return math.tan(math.radians(x))

    def asin(self, x):
        return math.degrees(math.asin(x))

    def acos(self, x):
        return math.degrees(math.acos(x))

    def atan(self, x):
        return math.degrees(math.atan(x))

    def encode(self, s):
        return s.encode(encoding=self.encoding)

    def decode(self, s):
        return s.decode(encoding=self.encoding)
    
    def degtostep(self, *args):
        decimals = 0
        spr = 200
        dpr = 360/spr
        t = ()

        for arg in args:
            try: 
                arg = int(arg)
            except:
                return 0
            t += (int(round(arg/dpr, decimals)),)
        return t

    def steptodeg(self, *args):
        decimals = 0
        spr = 200
        dpr = 360/spr
        t = ()
        for arg in args:
            try:
                arg = int(arg)
            except:
                return 0
            t += (int(round(arg*dpr, decimals)),)
        return t
        
    def point_xyz(self, x, y, z, rx, ry, rz, r):
        try:
            if x == 0 and y > 0:
                xyrot = 90
            elif x < 0 and y == 0:
                xyrot = 180
            elif x == 0 and y < 0:
                xyrot = 270
            elif x > 0 and y == 0:
                xyrot = 0
            elif x > 0 and y > 0:
                xyrot = self.atan(y / x)
            elif x < 0 and y > 0:
                xyrot = self.atan(y / x) + 180
            elif x < 0 and y < 0:
                xyrot = self.atan(y / x) + 180
            elif x > 0 and y < 0:
                xyrot = self.atan(y / x) + 360
            elif x == 0 and y == 0:
                return 0
            else:
                return 0
            if (xyrot - rx) < ((360 - xyrot) + rx):
                theta1 = xyrot - rx
            elif (xyrot - rx) == ((360 - xyrot) + rx):
                theta1 = xyrot - rx
            elif (xyrot - rx) > ((360 - xyrot) + rx):
                theta1 = -((360 - xyrot) + rx)
            else:
                return 0
            newx = x
            newy = y
            if x < 0:
                newx = -x
            if y < 0:
                newy = -y
            theta2_p1 = self.atan(z / math.sqrt(x**2 + y**2))
            theta2_p2 = self.acos(math.sqrt(x**2 + y**2 + z**2) / (2*r))
            theta2 = (theta2_p1 + theta2_p2) - ry
            theta2rsv = (theta2_p1 + theta2_p2)
            if theta2rsv > 90:
                lengthx = math.sqrt(x**2 + y**2) + (-(r * self.cos(theta2rsv)))
            elif theta2rsv <= 90:
                lengthx = math.sqrt(x**2 + y**2) - (r* self.cos(theta2rsv))
            else:
                return 0
            print(lengthx)

            theta3 = (theta2rsv + self.acos(lengthx / r)) - rz
        except Exception as e:
            print(e)
            print("An Error has occured and was handled")
        else:
            return(theta1, theta2, theta3)
        return

    def connect(self):
        try:
            self.socket = socket.socket()
            self.socket.connect((self.ip, self.port))
        except:
            return 0
        else:
            self.connected = True
            return 1

    def close_connection(self):
        if self.connected:
            self.send("CLOSE")
            self.connected = False
            return 1
        else:
            return 0

    def get(self):
        if self.connected:
            return self.decode(self.socket.recv(1024))
        else:
            return 0

    def send(self, *args):
        if self.connected:
            for arg in args:
                self.socket.send(self.encode(arg))
            return 1
        else:
            return 0

    def transform(self, joint, degrees, delay):
        if not int(joint) in range(self.joints+1):
            print("1")
            return 0
        try:
            float(degrees)
            float(delay)
        except:
            print("2")
            return 0
        if self.connected:
            self.send("T"+str(joint)+"/"+str(degrees)+"/"+str(delay))
            print("3")
            return 1
        else:
            print("4")
            return 0

    def localtransform(self, steps1, steps2, steps3, executiontime):
        try:
            int(steps1)
            int(steps2)
            int(steps3)
            float(executiontime)
        except:
            return 0
        if self.connected:
            self.send("LT"+str(steps1)+"/"+str(steps2)+"/"+str(steps3)+"/"+str(executiontime))
            return 1
        else:
            return 0

    def get_transform(self, *args):
        for arg in args:
            if not arg in range(self.joints+1):
                return 0
        if self.connected:
            jl = ()
            for arg in args:
                self.send("GT"+str(arg))
                jl += (self.get(),)
            return jl
        else:
            return 0

    def calibrate(self):
        if self.connected:
            self.send("C")
            return 1
        else:
            return 0

    def shutdown(self, days=0, hrs=0, mins=0, secs=0):
        try:
            days = int(days)
            hrs = int(hrs)
            mins = int(mins)
            secs = int(secs)
        except:
            return 0
        if days < 0 or hrs < 0 or mins < 0 or secs < 0:
            return 0
        ts = (days*86400) + (hrs*3600) + (mins*60) + secs
        if self.connected:
            self.send("SD"+str(ts))
            return 1
        else:
            return 0

    def restart(self, days=0, hrs=0, mins=0, secs=0):
        try:
            days = int(days)
            hrs = int(hrs)
            mins = int(mins)
            secs = int(secs)
        except:
            return 0
        if days < 0 or hrs < 0 or mins < 0 or secs < 0:
            return 0
        ts = (days*86400) + (hrs*3600) + (mins*60) + secs
        if self.connected:
            self.send("RT"+str(ts))
            return 1
        else:
            return 0

    def start_learn_sequence(self):
        if self.connected:
            self.send("BL")
            return 1
        else:
            return 0

    def stop_learn_sequence(self):
        if self.connected:
            self.send("SL")
            return 1
        else:
            return 0

    def get_sequences(self):
        if self.connected:
            self.send("GS")
            return self.get()
        else:
            return 0

    def play_sequence(self, sequence, times):
        if self.connected:
            current = self.get_sequences()
            if not str(sequence) in current:
                return 0
            else:
                self.send("PS"+str(sequence)+"/"+str(times))
                return 1
        else:
            return 0

    def rename_sequence(self, sequence, name):
        if self.connected:
            current = self.get_sequences()
            if name == "" or name == None:
                return 0
            if not str(sequence) in current:
                return 0
            else:
                self.send("RS"+str(sequence)+"/"+str(name))

    def get_sequence_name(self, sequence):
        if self.connected:
            seqs = self.get_sequences()
            if not str(sequence) in seqs:
                return 0
            elif str(sequence) in seqs:
                self.send("GSN"+str(sequence))
                return self.get()
            else:
                return 0
        else:
            return 0

    def remove_sequences(self):
        if self.connected:
            self.send("RMAS")
            return 1
        else:
            return 0

    def remove_sequence(self, sequence):
        if self.connected:
            seqs = self.get_sequences()
            try:
                str(sequence)
            except:
                print("s1")
                return 0
            else:
                sequence = str(sequence)
            if sequence in seqs:
                self.send("RMS"+str(sequence))
                return 1
            else:
                return 0
        else:
            return 0
        return 0
    def toint(self,*args):
        t = ()
        for arg in args:
            t += (int(arg),)
        return t
    def tofloat(self, *args):
        t = ()
        for arg in args:
            t += (float(arg),)
        return t
class CustomException(Exception):
    def __init__(self, message):
        self.parameter = message
    def __str__(self):
        return repr(self.parameter)

