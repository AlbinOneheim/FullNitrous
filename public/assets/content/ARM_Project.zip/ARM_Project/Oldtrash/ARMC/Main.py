import ARMLIB2 as Arm
import sys
import time

while True:
    ip = input("Enter a host: ")
    try:
        arm = Arm.Arm(ip)
    except Exception as e:
        print(e)
        print("ERROR: Invalid input")
    else:
        arm = Arm.Arm(ip)
        break

while True:
    if not arm.connected:
        data = input("<not connected> -> ")
    elif arm.connected:
        data = input(str(arm.ip)+":"+str(arm.port)+" -> ")
    else:
        print("ERROR: An unknown error has occured")
        time.sleep(3)
        exit()
    if data.lower().strip() == "point_xyz":
        x = input("x: ")
        y = input("y: ")
        z = input("z: ")
        try:
            x, y, z, = arm.toint(x,y,z)
        except:
            print("ERROR: Invalid input")
            continue
        else:
            print("INFO: ",arm.point_xyz(x, y, z, 0, 0, 0, 1))
        continue


    if data.lower().strip() == "connect":
        arm.connect()
        continue
    if data.lower().strip() == "disconnect":
        arm.close_connection()
        continue
    if data.lower().strip() == "transform":
        joint = input("joint: ")
        transform = input("transformation: ")
        delay = input("delay: ")
        try:
            joint = arm.toint(joint)
            transform = arm.tofloat(transform)
            delay = float(delay)
            arm.transform(joint[0],transform[0], delay)
        except Exception as e:
            print(e)
            print("ERROR: Invalid input")
            continue
        else:
            continue
    if data.lower().strip() == "transformall":
        s1 = input("joint1: ")
        s2 = input("joint2: ")
        s3 = input("joint3: ")
        time = input("fract: ")
        try:
            s1, s2, s3, time = arm.tofloat(s1, s2, s3, time)
        except Exception as e:
            print(e)
            print("ERROR: Invalid input")
        else:
            arm.localtransform(s1, s2, s3, time)
            continue
        continue
    if data.lower().strip() == "calibrate":
        arm.calibrate()
        continue
    if data.lower().strip() == "shutdown":
        print("In what amount of time do you want to shutdown: ")
        day = input("Days: ")
        hrs = input("Hours: ")
        mins = input("Minutes: ")
        sec = input("Seconds: ")
        try:
            day, hrs, mins, sec = arm.toint(day, hrs, mins, sec)
        except:
            print("ERROR: Invalid input")
            continue
        else:
            arm.shutdown(day, hrs, mins, sec)
            continue
        continue
    if data.lower().strip() == "restart":
        print("In what amount of time do you want to restart: ")
        day = input("Days: ")
        hrs = input("Hours: ")
        mins = input("Minutes: ")
        sec = input("Seconds: ")
        try:
            day, hrs, mins, sec = arm.toint(day, hrs, mins, sec)
        except:
            print("ERROR: Invalid input")
            continue
        else:
            arm.restart(day, hrs, mins, sec)
            continue
        continue
    if data.lower().strip() == "record":
        arm.start_learn_sequence()
        continue
    if data.lower().strip() == "save recording":
        arm.stop_learn_sequence()
        continue
    if data.lower().strip() == "remove all recordings":
        arm.remove_sequences()
        continue
    if data.lower().strip() == "remove a recording":
        sequence = input("Enter recording number: ")
        arm.remove_sequence(sequence)
        continue
    if data.lower().strip() == "get recording name":
        sequence = input("Enter recording number: ")
        try:
            sequence = int(sequence)
        except Exception as e:
            print(e)
            print("Error: Invalid input:")
            continue
        else:
            print(arm.get_sequence_name(sequence))
            continue
        continue
    if data.lower().strip() == "rename recording":
        newname = input("Enter new name: ")
        sequence = input("Select recording: ")
        try:
            sequence = int(sequence)
        except Exception as e:
            print(e)
            print("ERROR: Invalid input")
        else:
            print(arm.rename_sequence(sequence,newname))
            continue
        continue
    if data.lower().strip() == "fetch recordings":
        dataset = arm.get_sequences()
        dataset = dataset[1:]
        for i in range(len(dataset.replace("\\",""))):
            message = "|Record Nr: "+str(i+1)+" Name: "+str(arm.get_sequence_name(str(i+1)))+"|"
            print("-"*len(message))
            print(message)
            print("-"*len(message))
        continue
    if data.lower().strip() == "exit":
        arm.close_connection()
        exit()

    if data.lower().strip() == "help":
        print("Valid commands: ")
        print("point_xyz")
        print("connect")
        print("disconnect")
        print("transform")
        print("transformall")
        print("calibrate")
        print("shutdown")
        print("restart")
        print("record")
        print("save recording")
        print("remove all recordings")
        print("remove a recording")
        print("get recording name")
        print("rename recording")
        print("fetch recordings")
        print("help")
        print("exit")
    else:
        print("INFO: input not recognized, please enter \"help\" for information")
            
        
                
