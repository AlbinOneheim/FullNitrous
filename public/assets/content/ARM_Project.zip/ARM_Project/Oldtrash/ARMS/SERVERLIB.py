import socket
import os
import sys
import time
from threading import Thread
import RPi.GPIO as GPIO
class Server():
    def __init__(self, host="127.0.0.1", port=6969, encoding="UTF-8"):
        self.host = host
        self.port = port
        self.run = True
        self.client = None
        self.address = None
        self.sequence_names = {}

        self.encoding = encoding

    def setupclient(self):
        self.create_sequence_list()
        self.mainloop()
    def listen(self):
        print("INFO: initialized server")
        while self.run:
            self.s = socket.socket()
            self.s.bind((self.host, self.port))
            self.s.listen(1)
            self.client, self.address = self.s.accept()
            self.setupclient()

    def start_server(self):
        self.listen()

    def close_server(self):
        self.run = False
    def close_socket(self):
        self.s.close()
    def encode(self,s):
        return s.encode(encoding=self.encoding)

    def decode(self,s):
        return s.decode(encoding=self.encoding)

    def create_sequence_list(self):
        filelist = []
        for path in os.scandir(os.getcwd()+"\\Manifest\\Sequences"):
            filelist.append(path.path)
        i = 1
        for file in filelist:
            f = open(file,"r")
            self.sequence_names[str(i)] = f.readline().replace("name","").strip()
            i += 1

        return 
    
    def transform(self):
        if self.data[0] == "T":
            joint = self.data[1]
            degrees = ""

            for char in self.data[3:]:
                if char == "/":
                    break
                else:
                    degrees += char
                    
            delay = float(self.data[3+len(degrees)+1:])

            degrees = float(degrees)
            
            print(joint, degrees, delay)
            
            self.client.send(self.encode("transform resp"))
            if joint == "3":
                motorcallin.entry(0, 0, degrees)
            elif joint == "2":
                motorcallin.entry(0, degrees, 0)
            elif joint == "1":
                motorcallin.entry(degrees, 0, 0)


    def localtransform(self):
        steps1 = ""
        steps2 = ""
        steps3 = ""
        delay = ""
        for char in self.data[2:]:
            if char != "/":
                steps1 += char
            else:
                break
        for char in self.data[3+len(steps1):]:
            if char != "/":
                steps2 += char
            else:
                break
        for char in self.data[4+len(steps1)+len(steps2):]:
            if char != "/":
                steps3 += char
            else:
                break
        for char in self.data[5+len(steps1+steps2+steps3):]:
            if char != "/":
                delay += char
            else:
                break

        motorcallin.entry(steps1, steps2, steps3, float(delay))

    def get_transform(self):
        joint = self.data[2:]

        string = ""
        f = open(os.getcwd()+"\\Manifest\\SaveData\\POS","r")
        lines = f.readlines()
        i = 0
        for line in lines:
            string += line+"/"
            i += 1
        f.close()

        self.client.send(self.encode(string))

    def calibrate(self):
        L = []
        print(L)
        for element in motorcallin.step:
            L.append(-element)
            print(-element)
        motorcallin.entry(L[0],L[1],L[2], stepsenb = 1)

    def shutdown(self, delay):
        time.sleep(delay)
        os.system("sudo shutdown -h now")

    def restart(self, delay):
        time.sleep(delay)
        os.system("sudo shutdown -r now")

    #not finished
    def start_learn_sequence(self):
        # make a file called with the name of the number following up to the number
        # of the last file name with no file extention
        # 
        # start getting rotational data from the rotary encoders and write the concatenated
        # data to the created file
        # in a while loop depending on a global variable
        #
        # in the end of the loop make a statement that saves all the recorded data and exits
        # the function gracefully
        pass
    #not finished
    def stop_learn_sequence(self):
        # change the variable global variable for the while loop in
        # function start_learn_sequence to make a boolean 0 for the while
        # loop so it stops looping to save data
        pass

    def get_sequences(self):
        filelist = []
        string = ""
        for path in os.scandir(os.getcwd()+"\\Manifest\\Sequences"):
            filelist.append(path.path.replace(os.getcwd()+"\\Manifest\\Sequences",""))
        for file in filelist:
            string += file
        self.client.send(self.encode(string))

    def play_sequence(self):
        sequence = ""
        times = ""
        for chars in self.data[2:]:
            if chars != "/":
                sequence += chars
            else:
                break
        for chars in self.data[2+len(sequence):]:
            times += chars
        if not int(times):
            return
        f = open(os.getcwd()+"\\Manifest\\Sequences\\"+sequence,"r")
        d = f.readline()
        l = [0,0,0]
        for char in d:
            if char == ",":
                break
            l[0] += d
        for char in d:
            if char == ",":
                break
            l[1] += d
        for char in d:
            if char == ",":
                break
            l[2] += d
        t = [0,0,0]
        for i in range(3):
            t[i] = motorcallin.step[i] - l[i] 
        motorcallin.entry(t[0],t[1],t[2])
        for i in range(int(times)):
            d = f.readline()
            if d == "":
                f = open(os.getcwd()+"\\Manifest\\Sequences\\"+sequence,"r")
                f.readline()
                d = f.readline()
            l = [0,0,0]
            for char in d:
                if char == ",":
                    break
                l[0] += d
            for char in d:
                if char == ",":
                    break
                l[1] += d
            for char in d:
                if char == ",":
                    break
                l[2] += d
            motorcallin.entry(l[0],l[1],l[2])

    def rename_sequence(self):
        sequence = ""
        name = ""
        filetochange = ""
        for chars in self.data[2:]:
            if chars != "/":
                sequence += chars
            else:
                break
        for chars in self.data[3+len(sequence):]:
            name += chars
        for keyword in self.sequence_names:
            if keyword == sequence:
                filetochange = keyword
                break
        f = open(os.getcwd()+"\\Manifest\\Sequences\\"+str(filetochange), "r")
        wordlist = f.readlines()
        wordlist[0] = "name "+name+"\n"
        f.close()
        f = open(os.getcwd()+"\\Manifest\\Sequences\\"+str(filetochange), "w").close()
        f = open(os.getcwd()+"\\Manifest\\Sequences\\"+str(filetochange), "w")
        for line in wordlist:
            f.write(line)
        f.close()
        self.create_sequence_list()
        return

    def get_sequence_name(self):
        seq = ""
        for chars in self.data[3:]:
            seq += chars
        try:
            self.create_sequence_list()
            self.client.send(self.encode(self.sequence_names[seq]))
        except:
            self.client.send(self.encode("0"))
            return 0
        else:
            return 1
        return 0

    def remove_sequences(self):
        filelist = []
        for path in os.scandir(os.getcwd()+"\\Manifest\\Sequences\\"):
            filelist.append(path.path)
        for file in filelist:
            os.remove(file)

    def remove_sequence(self):
        sequence = ""
        deleted = 0
        filelist = []
        for chars in self.data[3:]:
            sequence += chars
        print("sequence: "+sequence)
        for path in os.scandir(os.getcwd()+"\\Manifest\\Sequences"):
            filelist.append(path.path.replace(os.getcwd()+"\\Manifest\\Sequences", "").replace("\\", ""))
        for file in filelist:
            if sequence == file:
                os.remove(os.getcwd()+"\\Manifest\\Sequences\\"+file)
                deleted = int(file)
        
        for path in os.scandir(os.getcwd()+"\\Manifest\\Sequences"):
            if int(path.path.replace(os.getcwd()+"\\Manifest\\Sequences","").replace("\\","")) > deleted:
                os.rename(path.path,os.getcwd()+"\\Manifest\\Sequences\\" +
                str(int(path.path.replace(os.getcwd()+"\\Manifest\\Sequences","")
                .replace("\\",""))-1))
            else:
                continue
                
    def perform_action(self):
        if self.data[0] == "T":
            self.transform()
            return 1
        elif self.data[:2] == "LT":
            self.localtransform()
            return 1
        elif self.data[:2] == "GT":
            self.get_transform()
            return 1
        elif self.data[0] == "C":
            self.calibrate()
            return 1
        elif self.data[:2] == "SD":
            delay = int(self.data[2:])
            t = Thread(target = lambda : self.shutdown(delay))
            t.start()
            return 1
        elif self.data[:2] == "RT":
            delay = int(self.data[2:])
            t = Thead(target = lambda : self.restart(delay))
            t.start()
            return 1
        elif self.data[:2] == "BL":
            self.start_learn_sequence()
            return 1
        elif self.data[:2] == "SL":
            self.stop_learn_sequence()
            return 1
        elif self.data[:3] == "GSN":
            self.get_sequence_name()
            return 1
        elif self.data[:2] == "GS":
            self.get_sequences()
            return 1
        elif self.data[:2] == "PS":
            self.play_sequence()
            return 1
        elif self.data[:2] == "RS":
            self.rename_sequence()
            return 1
        elif self.data[:4] == "RMAS":
            self.remove_sequences()
            return 1
        elif self.data[:3] == "RMS":
            self.remove_sequence()
            return 1
        else:
            return 0

    def mainloop(self):
        print("INFO: Server has connected to a client with address "+str(self.address))
        while True:
            try:
                self.data = self.decode(self.client.recv(1024))
                if self.data == "CLOSE":
                    break
                self.perform_action()
            except Exception as e:
                print(e)
                print("ERROR: An error has occured program will disconnect user")
                print("INFO: server has disconnected client "+str(self.address))
                self.close_socket()
                return
        print("INFO: Server has disconnected client "+str(self.address))
        self.close_socket()
        return



class MvStep():
    def __init__(self,stepper360):
        self.step = [0,0,0]
        self.step_360 = stepper360
        self.g = 360 / stepper360
        f = open(os.getcwd()+"\\Manifest\\SaveData\\POS","r")
        lines = f.readlines()
        i = 0
        for line in lines:
            self.step[i] = int(line)
            i += 1
        f.close()

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(6,GPIO.OUT)
        GPIO.setup(13,GPIO.OUT)
        GPIO.setup(19,GPIO.OUT)
        GPIO.setup(26,GPIO.OUT)
        
    def entry(self, theta1, theta2, theta3, delay = 0, stepsenb = 0):
        sl = [0,0,0]
        if not stepsenb:
            sl[0] = int(round(float(theta1) / self.g, 0))
            sl[1] = int(round(float(theta2) / self.g, 0))
            sl[2] = int(round(float(theta3) / self.g, 0))
        else:
            sl[0] = theta1
            sl[1] = theta2
            sl[2] = theta3
        i = 0
        for element in sl:
            self.step[i] += element
            i += 1
        i = 0
        ng = [0,0,0]
        for element in sl:
            if element < 0:
                sl[i] = -sl[i]
                ng[i] = 1
            i += 1
        large = max(sl[0], sl[1], sl[2])
        for i in range(large):
            if i < sl[0]:

                if ng[0]:
                    #print("direction 1")
                    GPIO.output(6,1)
                else:
                    #print("direction 0")
                    GPIO.output(6,0)

                #print("controller 1 enb")
                #print("pulse")
                #print("controller 1 dis")
                GPIO.output(13,1)
                GPIO.output(13,0)
                
            if i < sl[1]:
                
                if ng[1]:
                    #print("direction 1")
                    GPIO.output(6,1)
                else:
                    #print("direction 0")
                    GPIO.output(6,0)
                    

                #print("controlelr 2 enb")
                #print("pulse")
                #print("controller 2 dis")
                GPIO.output(19,1)
                GPIO.output(19,0)

            if i < sl[2]:
                
                if ng[2]:
                    #print("direction 1")
                    GPIO.output(6,1)
                else:
                    #print("direction 0")
                    GPIO.output(6,0)                    

                #print("controller 3 enb")
                #print("pulse")
                #print("controller 3 dis")
                GPIO.output(26,1)
                GPIO.output(26,0)

            time.sleep(delay)
        self.save()
    def save(self):
        f = open(os.getcwd()+"\\Manifest\\SaveData\\POS","w")
        i = 0
        for element in self.step:
            f.write(str(self.step[i])+"\n")
            i += 1
        f.close()
motorcallin = MvStep(3200)