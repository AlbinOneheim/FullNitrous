import SERVERLIB as s

server = s.Server()
server.start_server()
