#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <util/twi.h>
#include <stdlib.h>
#include <avr/interrupt.h>


int main(void)
{
	DDRD |= _BV(2);
	int delay = 550;

	int i;

	for (i = 0; i < 200; i++)
	{
		PORTD |= _BV(2);
		_delay_us(delay);
		PORTD &= ~_BV(2);
		_delay_us(delay);
	}

	_delay_ms(10000);

	while(1)
	{
		PORTD |= _BV(2);
		_delay_us(delay);
		PORTD &= ~_BV(2);
		_delay_us(delay);
	}
	return 0;
}

